package com.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingJpaMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingJpaMsApplication.class, args);
	}

}
